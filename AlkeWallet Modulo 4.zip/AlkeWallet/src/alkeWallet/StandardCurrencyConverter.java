package alkeWallet;

import java.util.HashMap;
import java.util.Map;

public class StandardCurrencyConverter implements CurrencyConverter {
    private Map<String, Double> conversionRates;

    public StandardCurrencyConverter() {
        conversionRates = new HashMap<>();
        conversionRates.put("CLP", 1.0);
        conversionRates.put("USD", 900.0); // 1 USD = 800 CLP
    }

    @Override
    public double getExchangeRate() {
        return conversionRates.get("USD");
    }

    @Override
    public double convertCLPtoUSD(double amountCLP) {
        return amountCLP / getExchangeRate();
    }

    @Override
    public double convertUSDtoCLP(double amountUSD) {
        return amountUSD * getExchangeRate();
    }
}