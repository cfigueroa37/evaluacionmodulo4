package alkeWallet;

public interface CurrencyConverter {
    double getExchangeRate();
    double convertCLPtoUSD(double amountCLP);
    double convertUSDtoCLP(double amountUSD);
}



