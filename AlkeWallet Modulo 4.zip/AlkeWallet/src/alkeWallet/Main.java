package alkeWallet;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		UserManager userManager = new UserManager();
        CurrencyConverter currencyConverter = new StandardCurrencyConverter();

        Wallet wallet = new Wallet(currencyConverter);

        userManager.registerUser("carlos", "bootcamps");

        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese su nombre de usuario:");
        String username = scanner.nextLine();

        System.out.println("Ingrese su contraseña:");
        String password = scanner.nextLine();

        User user = userManager.verifyUser(username, password);
        if (user != null) {
            wallet.setCurrentUser(user);
            System.out.println("Usuario verificado.");
        } else {
            System.out.println("Usuario o contraseña incorrectos.");
            return;
        }

        while (true) {
            System.out.println("Seleccione una opción:");
            System.out.println("1. Depositar");
            System.out.println("2. Retirar");
            System.out.println("3. Consultar saldo en CLP");
            System.out.println("4. Consultar saldo en USD");
            System.out.println("5. Salir");

            int option = scanner.nextInt();
            switch (option) {
                case 1:
                    System.out.println("Ingrese el monto a depositar:");
                    double depositAmount = scanner.nextDouble();
                    try {
                        wallet.deposit(depositAmount);
                        System.out.println("Deposito exitoso.");
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 2:
                    System.out.println("Ingrese el monto a retirar:");
                    double withdrawAmount = scanner.nextDouble();
                    try {
                        wallet.withdraw(withdrawAmount);
                        System.out.println("Retiro exitoso.");
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    System.out.println("Saldo actual en CLP: " + wallet.checkBalance());
                    break;
                case 4:
                    System.out.println("Saldo actual en USD: " + wallet.checkBalanceInUSD());
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }
}