package alkeWallet;

public class Wallet {
    private User currentUser;
    private CurrencyConverter currencyConverter;

    public Wallet(CurrencyConverter currencyConverter) {
        this.currencyConverter = currencyConverter;
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    public double checkBalance() {
        if (currentUser != null) {
            return currentUser.getBalance();
        }
        throw new IllegalStateException("No user logged in.");
    }

    public void deposit(double amount) {
        if (currentUser != null) {
            currentUser.deposit(amount);
        } else {
            throw new IllegalStateException("No user logged in.");
        }
    }

    public void withdraw(double amount) {
        if (currentUser != null) {
            currentUser.withdraw(amount);
        } else {
            throw new IllegalStateException("No user logged in.");
        }
    }

    public double checkBalanceInUSD() {
        if (currentUser != null) {
            return currencyConverter.convertCLPtoUSD(currentUser.getBalance());
        }
        throw new IllegalStateException("No user logged in.");

    }
}