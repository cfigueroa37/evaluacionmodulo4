package alkeWalletTest;


import org.junit.jupiter.api.Test;
import alkeWallet.User;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Clase de prueba para Usuario
 */
public class UserTest {

	/** 
	 * prueba para clase deposito
	 */
    @Test
    public void testDeposit() {
        User user = new User("carlos", "bootcamps");
        user.deposit(1000);
        assertEquals(1000, user.getBalance());
    }

    /**
     * pueba para clase retiro
     */
    @Test
    public void testWithdraw() {
        User user = new User("carlos", "bootcamps");
        user.deposit(1000);
        user.withdraw(500);
        assertEquals(500, user.getBalance());
    }

    /**
     * Prueba de retirar fondos
     */
    @Test
    public void testWithdrawInsufficientFunds() {
        User user = new User("carlos", "bootcamps");
        user.deposit(500);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            user.withdraw(1000);
        });
        assertEquals("Fondos Insuficientes.", exception.getMessage());
    }

    /**
     * Prueba de Deposito negativo
     */
    @Test
    public void testNegativeDeposit() {
        User user = new User("carlos", "bootcamps");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            user.deposit(-100);
        });
        assertEquals("Monto del deposito debe ser mayor a cero.", exception.getMessage());
    }

    /**
     * Prueba de retiro negativo
     */
    @Test
    public void testNegativeWithdraw() {
        User user = new User("carlos", "bootcamps");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            user.withdraw(-100);
        });
        assertEquals("Monto del retiro debe ser mayor a cero..", exception.getMessage());
    }
}

